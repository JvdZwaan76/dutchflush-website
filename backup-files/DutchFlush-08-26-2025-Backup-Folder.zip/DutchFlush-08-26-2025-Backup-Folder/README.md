# dutchflush-website
DutchFlush.com Website

## Deployment Instructions
1. Upload all files to your web server root.
2. Ensure HTTPS is enabled for security and SEO.
3. Submit sitemap.xml to Google Search Console.
4. Test on multiple devices/browsers for compatibility.
